# Specification

## Summary
**Goal:** Add an admin-only dashboard that lets authorized admins view registered user details, backed by a stable user registry and Internet Identity sign-in UI.

**Planned changes:**
- Implement a backend user registry that records/updates users on authentication (principal, firstSeen, lastSeen) and persists it in stable storage.
- Add backend admin authorization plus admin-only query methods to list all users and fetch a single user by principal (reject non-admin callers).
- Add minimal Internet Identity authentication controls in the frontend header (Sign in / Sign out + shortened principal).
- Add an admin-only Admin Dashboard UI that appears only for authenticated admins and displays a table of users (principal, firstSeen, lastSeen) fetched via the existing React Query setup.

**User-visible outcome:** Users can sign in/out with Internet Identity and see their principal in the header; admins (and only admins) can open an Admin Dashboard to view a table of all registered users and their timestamps.
