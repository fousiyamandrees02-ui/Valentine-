import { Heart } from 'lucide-react';

export default function FloatingHearts() {
  const hearts = Array.from({ length: 12 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    delay: `${Math.random() * 8}s`,
    size: Math.random() > 0.5 ? 'w-4 h-4' : 'w-6 h-6',
    animation: Math.random() > 0.5 ? 'animate-float-up' : 'animate-float-up-alt',
  }));

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5" />
      
      {/* Floating hearts */}
      {hearts.map((heart) => (
        <Heart
          key={heart.id}
          className={`absolute bottom-0 text-primary/20 fill-primary/10 ${heart.size} ${heart.animation}`}
          style={{
            left: heart.left,
            animationDelay: heart.delay,
          }}
        />
      ))}
    </div>
  );
}
