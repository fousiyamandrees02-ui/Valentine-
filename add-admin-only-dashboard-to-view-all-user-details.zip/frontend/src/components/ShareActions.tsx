import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Share2, Copy, Check } from 'lucide-react';
import { SiWhatsapp, SiInstagram } from 'react-icons/si';
import { buildShareUrl, buildWhatsAppUrl, buildInstagramCaption } from '../lib/share';
import type { CompatibilityResult } from '../App';

interface ShareActionsProps {
  result: CompatibilityResult;
}

export default function ShareActions({ result }: ShareActionsProps) {
  const [copied, setCopied] = useState(false);
  const [showInstagram, setShowInstagram] = useState(false);

  const shareUrl = buildShareUrl(result);
  const whatsappUrl = buildWhatsAppUrl(result, shareUrl);
  const instagramCaption = buildInstagramCaption(result, shareUrl);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleCopyInstagramCaption = async () => {
    try {
      await navigator.clipboard.writeText(instagramCaption);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  return (
    <>
      <Card className="glass border shadow-lg">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              onClick={() => window.open(whatsappUrl, '_blank')}
              variant="outline"
              className="flex-1 h-12 transition-smooth hover:scale-105"
            >
              <SiWhatsapp className="w-5 h-5 mr-2" />
              WhatsApp
            </Button>

            <Button
              onClick={() => setShowInstagram(true)}
              variant="outline"
              className="flex-1 h-12 transition-smooth hover:scale-105"
            >
              <SiInstagram className="w-5 h-5 mr-2" />
              Instagram
            </Button>

            <Button
              onClick={handleCopyLink}
              variant="outline"
              className="flex-1 h-12 transition-smooth hover:scale-105"
            >
              {copied ? (
                <>
                  <Check className="w-5 h-5 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5 mr-2" />
                  Copy Link
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showInstagram} onOpenChange={setShowInstagram}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <SiInstagram className="w-5 h-5" />
              Share on Instagram
            </DialogTitle>
            <DialogDescription>
              Copy the caption below and share it on Instagram!
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm whitespace-pre-wrap break-words">{instagramCaption}</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCopyInstagramCaption} className="flex-1">
                {copied ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Caption
                  </>
                )}
              </Button>
              <Button
                onClick={() => window.open('https://www.instagram.com/', '_blank')}
                variant="outline"
              >
                <SiInstagram className="w-4 h-4 mr-2" />
                Open Instagram
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
