import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useIsCallerAdmin, useGetAllUserDetails } from '../hooks/useAdminUsers';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Shield, ShieldAlert, Users } from 'lucide-react';
import { formatTime, formatRelativeTime } from '../lib/time';
import { truncatePrincipal } from '../lib/principal';

export default function AdminDashboardSection() {
  const { identity } = useInternetIdentity();
  const isAuthenticated = !!identity && !identity.getPrincipal().isAnonymous();
  
  const { data: isAdmin, isLoading: isAdminLoading } = useIsCallerAdmin();
  const { data: users, isLoading: usersLoading, error } = useGetAllUserDetails();

  // Don't show anything if not authenticated
  if (!isAuthenticated) {
    return null;
  }

  // Show loading state while checking admin status
  if (isAdminLoading) {
    return (
      <section className="max-w-6xl mx-auto mt-12">
        <Card className="glass-card">
          <CardHeader>
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-64 mt-2" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-32 w-full" />
          </CardContent>
        </Card>
      </section>
    );
  }

  // Show access denied if not admin
  if (!isAdmin) {
    return (
      <section className="max-w-6xl mx-auto mt-12">
        <Alert variant="destructive" className="glass-card">
          <ShieldAlert className="h-5 w-5" />
          <AlertTitle>Access Denied</AlertTitle>
          <AlertDescription>
            You do not have permission to view the admin dashboard. This area is restricted to administrators only.
          </AlertDescription>
        </Alert>
      </section>
    );
  }

  // Admin view
  return (
    <section className="max-w-6xl mx-auto mt-12">
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            <CardTitle className="text-2xl">Admin Dashboard</CardTitle>
          </div>
          <CardDescription>
            View and manage all registered users
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error ? (
            <Alert variant="destructive">
              <ShieldAlert className="h-5 w-5" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error instanceof Error ? error.message : 'Failed to load user details'}
              </AlertDescription>
            </Alert>
          ) : usersLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : !users || users.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No users registered yet</p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">Principal</TableHead>
                    <TableHead className="w-[30%]">First Seen</TableHead>
                    <TableHead className="w-[30%]">Last Seen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.principal.toString()}>
                      <TableCell className="font-mono text-sm">
                        <div className="flex flex-col gap-1">
                          <span className="hidden lg:inline">{user.principal.toString()}</span>
                          <span className="lg:hidden">{truncatePrincipal(user.principal.toString(), 10, 8)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <span className="text-sm">{formatTime(user.firstSeen)}</span>
                          <span className="text-xs text-muted-foreground">{formatRelativeTime(user.firstSeen)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <span className="text-sm">{formatTime(user.lastSeen)}</span>
                          <span className="text-xs text-muted-foreground">{formatRelativeTime(user.lastSeen)}</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          {users && users.length > 0 && (
            <div className="mt-4 text-sm text-muted-foreground">
              Total users: {users.length}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
