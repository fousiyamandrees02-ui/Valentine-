import { Card, CardContent } from '@/components/ui/card';
import { Heart, Sparkles } from 'lucide-react';

export default function CompatibilityLoading() {
  return (
    <Card className="glass border-2 shadow-2xl animate-fade-in-up" role="status" aria-live="polite" aria-busy="true">
      <CardContent className="py-16 flex flex-col items-center justify-center space-y-6">
        <div className="relative">
          <Heart className="w-20 h-20 text-primary fill-primary animate-heartbeat" />
          <Sparkles className="w-6 h-6 text-secondary absolute -top-2 -right-2 animate-sparkle" />
          <Sparkles className="w-6 h-6 text-accent absolute -bottom-2 -left-2 animate-sparkle" style={{ animationDelay: '0.5s' }} />
        </div>
        <div className="text-center space-y-2">
          <p className="text-xl md:text-2xl font-semibold gradient-text">
            Calculating your connection...
          </p>
          <p className="text-muted-foreground">
            The stars are aligning ✨
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
