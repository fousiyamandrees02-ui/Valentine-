import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Users, Sparkles, CircleDot, Swords, UserPlus } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import type { CompatibilityResult, FlamesResult } from '../App';

interface ResultCardProps {
  result: CompatibilityResult;
}

const resultConfig: Record<FlamesResult, { icon: React.ReactNode; emoji: string; color: string; message: string }> = {
  Friends: {
    icon: <Users className="w-16 h-16" />,
    emoji: '👫',
    color: 'text-chart-2',
    message: 'You share a wonderful friendship bond!',
  },
  Love: {
    icon: <Heart className="w-16 h-16 fill-current" />,
    emoji: '❤️',
    color: 'text-primary',
    message: 'Love is in the air for you two!',
  },
  Affection: {
    icon: <Sparkles className="w-16 h-16" />,
    emoji: '💕',
    color: 'text-secondary',
    message: 'There\'s a special affection between you!',
  },
  Marriage: {
    icon: <CircleDot className="w-16 h-16" />,
    emoji: '💍',
    color: 'text-accent',
    message: 'Wedding bells might be in your future!',
  },
  Enemies: {
    icon: <Swords className="w-16 h-16" />,
    emoji: '⚔️',
    color: 'text-destructive',
    message: 'Opposites attract... or repel!',
  },
  Siblings: {
    icon: <UserPlus className="w-16 h-16" />,
    emoji: '👨‍👩‍👧‍👦',
    color: 'text-chart-4',
    message: 'You share a sibling-like connection!',
  },
};

export default function ResultCard({ result }: ResultCardProps) {
  const config = resultConfig[result.result];

  return (
    <Card className="glass border-2 shadow-2xl animate-fade-in-up">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl md:text-3xl font-bold gradient-text">
          Compatibility Result
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 pb-8">
        {/* Input Section */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide text-center">
            Input
          </h3>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <span className="text-lg md:text-xl font-medium text-foreground px-4 py-2 bg-muted/50 rounded-lg">
              {result.name1}
            </span>
            <Heart className="w-5 h-5 text-primary fill-primary" />
            <span className="text-lg md:text-xl font-medium text-foreground px-4 py-2 bg-muted/50 rounded-lg">
              {result.name2}
            </span>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Output Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide text-center">
            Output
          </h3>
          
          <div className="text-center space-y-6">
            <div className={`flex justify-center ${config.color} animate-heartbeat`}>
              {config.icon}
            </div>
            
            <div className="space-y-2">
              <p className="text-6xl md:text-8xl" role="img" aria-label={result.result}>
                {config.emoji}
              </p>
              <h2 className="text-4xl md:text-5xl font-bold gradient-text">
                {result.result}
              </h2>
            </div>

            <p className="text-lg md:text-xl text-muted-foreground max-w-md mx-auto">
              {config.message}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
