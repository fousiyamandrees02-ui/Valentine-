import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useCompatibilityHistory } from '../hooks/useCompatibilityHistory';
import { History, Trash2, Heart } from 'lucide-react';
import type { CompatibilityResult } from '../App';

interface HistorySectionProps {
  onSelectEntry: (result: CompatibilityResult) => void;
}

export default function HistorySection({ onSelectEntry }: HistorySectionProps) {
  const { history, clearHistory } = useCompatibilityHistory();

  if (history.length === 0) {
    return null;
  }

  return (
    <Card className="glass border shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-primary" />
            <CardTitle>Recent Checks</CardTitle>
          </div>
          <Button
            onClick={clearHistory}
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-destructive transition-smooth"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Clear All
          </Button>
        </div>
        <CardDescription>Your compatibility check history</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          <div className="space-y-3">
            {history.map((entry, index) => (
              <div key={entry.timestamp}>
                {index > 0 && <Separator className="my-3" />}
                <button
                  onClick={() => onSelectEntry(entry)}
                  className="w-full text-left p-3 rounded-lg hover:bg-accent/50 transition-smooth focus-ring"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">
                        {entry.name1} & {entry.name2}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(entry.timestamp).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-primary">{entry.result}</span>
                      <Heart className="w-4 h-4 text-primary fill-primary" />
                    </div>
                  </div>
                </button>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
