import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { calculateFlames } from '../lib/flames';
import CompatibilityLoading from './CompatibilityLoading';
import type { CompatibilityResult } from '../App';
import { Heart } from 'lucide-react';

interface FlamesFormProps {
  onResult: (result: CompatibilityResult) => void;
}

export default function FlamesForm({ onResult }: FlamesFormProps) {
  const [name1, setName1] = useState('');
  const [name2, setName2] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ name1?: string; name2?: string }>({});

  const validateForm = (): boolean => {
    const newErrors: { name1?: string; name2?: string } = {};
    
    if (!name1.trim()) {
      newErrors.name1 = 'Please enter your name';
    }
    
    if (!name2.trim()) {
      newErrors.name2 = 'Please enter partner\'s name';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    
    // Simulate processing delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const result = calculateFlames(name1, name2);
    onResult({
      name1: name1.trim(),
      name2: name2.trim(),
      result,
    });
    
    setIsLoading(false);
  };

  if (isLoading) {
    return <CompatibilityLoading />;
  }

  return (
    <Card className="glass border-2 shadow-2xl animate-fade-in-up">
      <CardHeader className="text-center space-y-2">
        <CardTitle className="text-2xl md:text-3xl flex items-center justify-center gap-2">
          <Heart className="w-6 h-6 text-primary fill-primary" />
          Check Compatibility
          <Heart className="w-6 h-6 text-primary fill-primary" />
        </CardTitle>
        <CardDescription className="text-base">
          Enter both names to discover your relationship status
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name1" className="text-base">
              Your Name
            </Label>
            <Input
              id="name1"
              type="text"
              placeholder="Enter your name"
              value={name1}
              onChange={(e) => {
                setName1(e.target.value);
                if (errors.name1) setErrors({ ...errors, name1: undefined });
              }}
              className={`h-12 text-base transition-smooth focus-ring ${
                errors.name1 ? 'border-destructive' : ''
              }`}
              aria-invalid={!!errors.name1}
              aria-describedby={errors.name1 ? 'name1-error' : undefined}
            />
            {errors.name1 && (
              <p id="name1-error" className="text-sm text-destructive" role="alert">
                {errors.name1}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="name2" className="text-base">
              Partner's Name
            </Label>
            <Input
              id="name2"
              type="text"
              placeholder="Enter partner's name"
              value={name2}
              onChange={(e) => {
                setName2(e.target.value);
                if (errors.name2) setErrors({ ...errors, name2: undefined });
              }}
              className={`h-12 text-base transition-smooth focus-ring ${
                errors.name2 ? 'border-destructive' : ''
              }`}
              aria-invalid={!!errors.name2}
              aria-describedby={errors.name2 ? 'name2-error' : undefined}
            />
            {errors.name2 && (
              <p id="name2-error" className="text-sm text-destructive" role="alert">
                {errors.name2}
              </p>
            )}
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full h-14 text-lg font-semibold transition-smooth hover:scale-105 active:scale-95 animate-pulse-glow"
          >
            <Heart className="w-5 h-5 mr-2 fill-current" />
            Check Compatibility
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
