import { useState, useEffect } from 'react';
import FloatingHearts from './components/FloatingHearts';
import FlamesForm from './components/FlamesForm';
import ResultCard from './components/ResultCard';
import ShareActions from './components/ShareActions';
import HistorySection from './components/HistorySection';
import ThemeToggle from './components/ThemeToggle';
import AuthControls from './components/AuthControls';
import AdminDashboardSection from './components/AdminDashboardSection';
import { useCompatibilityHistory } from './hooks/useCompatibilityHistory';
import { Heart } from 'lucide-react';
import { SiX, SiFacebook, SiInstagram } from 'react-icons/si';

export type FlamesResult = 'Friends' | 'Love' | 'Affection' | 'Marriage' | 'Enemies' | 'Siblings';

export interface CompatibilityResult {
  name1: string;
  name2: string;
  result: FlamesResult;
}

function App() {
  const [result, setResult] = useState<CompatibilityResult | null>(null);
  const { addEntry } = useCompatibilityHistory();

  // Parse URL params on mount to restore shared results
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const name1 = params.get('name1');
    const name2 = params.get('name2');
    const resultParam = params.get('result') as FlamesResult | null;

    if (name1 && name2 && resultParam) {
      const validResults: FlamesResult[] = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
      if (validResults.includes(resultParam)) {
        setResult({ name1, name2, result: resultParam });
      }
    }
  }, []);

  const handleResult = (compatibilityResult: CompatibilityResult) => {
    setResult(compatibilityResult);
    addEntry(compatibilityResult);
  };

  const handleReset = () => {
    setResult(null);
    // Clear URL params
    window.history.replaceState({}, '', window.location.pathname);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      <FloatingHearts />
      
      {/* Header */}
      <header className="relative z-10 container mx-auto px-4 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6 text-primary fill-primary" />
          <span className="text-xl font-bold gradient-text">FLAMES</span>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <AuthControls />
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 container mx-auto px-4 py-8 md:py-12">
        {/* Hero Section */}
        <section className="text-center mb-12 md:mb-16">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 md:mb-6 gradient-text leading-tight">
            Discover Your Connection ❤️
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Enter two names and let the classic FLAMES algorithm reveal your relationship destiny
          </p>
        </section>

        {/* Form or Result */}
        <section className="max-w-2xl mx-auto mb-12">
          {!result ? (
            <FlamesForm onResult={handleResult} />
          ) : (
            <div className="space-y-6 animate-fade-in-up">
              <ResultCard result={result} />
              <ShareActions result={result} />
              <div className="text-center">
                <button
                  onClick={handleReset}
                  className="text-muted-foreground hover:text-foreground transition-smooth underline focus-ring rounded"
                >
                  Try another combination
                </button>
              </div>
            </div>
          )}
        </section>

        {/* History Section */}
        <section className="max-w-4xl mx-auto">
          <HistorySection onSelectEntry={handleResult} />
        </section>

        {/* Admin Dashboard Section */}
        <AdminDashboardSection />
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border mt-16 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © {new Date().getFullYear()} FLAMES Calculator. Built with{' '}
              <Heart className="inline w-4 h-4 text-primary fill-primary" /> using{' '}
              <a
                href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(
                  typeof window !== 'undefined' ? window.location.hostname : 'flames-calculator'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline focus-ring rounded"
              >
                caffeine.ai
              </a>
            </p>
            <div className="flex gap-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-smooth focus-ring rounded"
                aria-label="Twitter"
              >
                <SiX className="w-5 h-5" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-smooth focus-ring rounded"
                aria-label="Facebook"
              >
                <SiFacebook className="w-5 h-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-smooth focus-ring rounded"
                aria-label="Instagram"
              >
                <SiInstagram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
