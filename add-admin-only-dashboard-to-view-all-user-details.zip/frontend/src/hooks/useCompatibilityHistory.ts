import { useState, useEffect } from 'react';
import type { CompatibilityResult } from '../App';

interface HistoryEntry extends CompatibilityResult {
  timestamp: number;
}

const STORAGE_KEY = 'flames-history';
const MAX_HISTORY = 10;

export function useCompatibilityHistory() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // Load history from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as HistoryEntry[];
        setHistory(parsed);
      }
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  }, []);

  const addEntry = (result: CompatibilityResult) => {
    const newEntry: HistoryEntry = {
      ...result,
      timestamp: Date.now(),
    };

    setHistory((prev) => {
      const updated = [newEntry, ...prev].slice(0, MAX_HISTORY);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Failed to save history:', error);
      }
      return updated;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error('Failed to clear history:', error);
    }
  };

  return { history, addEntry, clearHistory };
}
