import { useQuery } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type { User } from '../backend';

/**
 * Hook to check if the current caller is an admin
 */
export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();
  
  const isAuthenticated = !!identity && !identity.getPrincipal().isAnonymous();

  return useQuery<boolean>({
    queryKey: ['isCallerAdmin'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      try {
        return await actor.isCallerAdmin();
      } catch (error) {
        // If the call fails (e.g., not authenticated), return false
        console.error('Error checking admin status:', error);
        return false;
      }
    },
    enabled: !!actor && !actorFetching && isAuthenticated,
    retry: false,
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });
}

/**
 * Hook to get all user details (admin only)
 */
export function useGetAllUserDetails() {
  const { actor, isFetching: actorFetching } = useActor();
  const { data: isAdmin, isLoading: isAdminLoading } = useIsCallerAdmin();

  return useQuery<User[]>({
    queryKey: ['allUserDetails'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      try {
        return await actor.getAllUserDetails();
      } catch (error: any) {
        // Handle authorization errors gracefully
        if (error.message?.includes('Unauthorized')) {
          throw new Error('Access denied: Admin privileges required');
        }
        throw error;
      }
    },
    enabled: !!actor && !actorFetching && !isAdminLoading && isAdmin === true,
    retry: false,
    staleTime: 30 * 1000, // Cache for 30 seconds
  });
}
