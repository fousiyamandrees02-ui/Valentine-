import type { CompatibilityResult } from '../App';

/**
 * Build a shareable URL with query parameters
 */
export function buildShareUrl(result: CompatibilityResult): string {
  const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : '';
  const params = new URLSearchParams({
    name1: result.name1,
    name2: result.name2,
    result: result.result,
  });
  return `${baseUrl}?${params.toString()}`;
}

/**
 * Build WhatsApp share URL
 */
export function buildWhatsAppUrl(result: CompatibilityResult, shareUrl: string): string {
  const message = `🔥 ${result.name1} & ${result.name2} are ${result.result}! ❤️\n\nCheck your compatibility: ${shareUrl}`;
  return `https://wa.me/?text=${encodeURIComponent(message)}`;
}

/**
 * Build Instagram caption
 */
export function buildInstagramCaption(result: CompatibilityResult, shareUrl: string): string {
  const emojis: Record<string, string> = {
    Friends: '👫',
    Love: '❤️',
    Affection: '💕',
    Marriage: '💍',
    Enemies: '⚔️',
    Siblings: '👨‍👩‍👧‍👦',
  };

  const emoji = emojis[result.result] || '❤️';

  return `${emoji} ${result.name1} & ${result.name2} are ${result.result}! ${emoji}

Check your own compatibility at:
${shareUrl}

#FLAMES #LoveCalculator #Compatibility #Relationship #Valentine`;
}
