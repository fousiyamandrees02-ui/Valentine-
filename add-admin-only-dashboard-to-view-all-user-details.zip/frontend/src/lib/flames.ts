import type { FlamesResult } from '../App';

/**
 * Calculate FLAMES result based on two names using the classic algorithm
 */
export function calculateFlames(name1: string, name2: string): FlamesResult {
  // Normalize names: trim, lowercase, remove spaces
  const n1 = name1.trim().toLowerCase().replace(/\s+/g, '');
  const n2 = name2.trim().toLowerCase().replace(/\s+/g, '');

  // Create character frequency maps
  const freq1 = new Map<string, number>();
  const freq2 = new Map<string, number>();

  for (const char of n1) {
    freq1.set(char, (freq1.get(char) || 0) + 1);
  }

  for (const char of n2) {
    freq2.set(char, (freq2.get(char) || 0) + 1);
  }

  // Count remaining characters after removing common ones
  let remainingCount = 0;

  // Add characters from name1 that don't match name2
  for (const [char, count] of freq1) {
    const matchCount = freq2.get(char) || 0;
    remainingCount += Math.abs(count - matchCount);
  }

  // Add characters from name2 that aren't in name1
  for (const [char, count] of freq2) {
    if (!freq1.has(char)) {
      remainingCount += count;
    }
  }

  // FLAMES array
  const flames: FlamesResult[] = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];

  // If no remaining count, default to Love
  if (remainingCount === 0) {
    return 'Love';
  }

  // Use modulo to determine result
  const index = (remainingCount - 1) % flames.length;
  return flames[index];
}
