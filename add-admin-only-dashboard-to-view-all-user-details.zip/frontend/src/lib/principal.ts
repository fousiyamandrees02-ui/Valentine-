/**
 * Truncates a principal string for display purposes
 * Shows first 8 and last 6 characters with ellipsis in between
 */
export function truncatePrincipal(principal: string, startChars = 8, endChars = 6): string {
  if (principal.length <= startChars + endChars) {
    return principal;
  }
  return `${principal.slice(0, startChars)}...${principal.slice(-endChars)}`;
}
